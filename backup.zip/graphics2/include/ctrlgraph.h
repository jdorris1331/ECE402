#ifndef CTRLGRAPH_H
#define CTRLGRAPH_H

#include <QFrame>

class CtrlGraph : public QFrame
{
public:
    CtrlGraph(QWidget *parent = 0);
};

#endif // CTRLGRAPH_H

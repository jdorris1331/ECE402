#ifndef CTRLMENUBAR_H
#define CTRLMENUBAR_H

//#include <Windows.h>
#include <FL/Fl_Menu_Bar.H>
#include <FL/Fl_Menu.H>
#include <FL/Fl_Menu_Item.H>

class CtrlMenuBar : public Fl_Menu_Bar
{
private:
	//Fl_Menu_Item *mbItems;

public:
	CtrlMenuBar();
};

#endif // CTRLMENUBAR_H

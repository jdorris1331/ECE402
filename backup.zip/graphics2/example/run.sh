

#!/bin/sh
make -C -f ../lib/ clean
make -C -f ../lib/
make clean
make
